package com.example.mpdcw;

public class MainListData {
    private String Location;
    private String Magnitude;
    private float maxMagnitude;

    public MainListData(String location, String magnitude, float maxMag) {
        Location = location;
        Magnitude = magnitude;
        maxMagnitude = maxMag;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String location) {
        Location = location;
    }

    public String getMagnitude() {
        return Magnitude;
    }

    public void setMagnitude(String magnitude) {
        Magnitude = magnitude;
    }

    public float getMaxMagnitude() {
        return maxMagnitude;
    }

    public void setMaxMagnitude(float maxMagnitude) {
        this.maxMagnitude = maxMagnitude;
    }
}
