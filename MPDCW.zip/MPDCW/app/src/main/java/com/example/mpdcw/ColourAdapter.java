package com.example.mpdcw;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class ColourAdapter extends ArrayAdapter<MainListData> {

    Context mContext;
    int mResource;

    public ColourAdapter(@NonNull Context context, int resource, @NonNull ArrayList<MainListData> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource=resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        String locationInfo = getItem(position).getLocation();
        String MagInfo = getItem(position).getMagnitude();

        LayoutInflater layoutInflater = LayoutInflater.from(mContext);
        convertView=layoutInflater.inflate(mResource,parent,false);

        TextView location = (TextView) convertView.findViewById(R.id.LocationView);
        TextView mag = (TextView) convertView.findViewById(R.id.MagnitudeView);

        location.setText(locationInfo);
        mag.setText(MagInfo);

        Float magFloat = Float.parseFloat(MagInfo.toString());
        Float maxAmount = getItem(position).getMaxMagnitude();

        mag.setBackgroundColor(Color.argb(1, 1 * (magFloat / maxAmount), 1 * (1 - (magFloat / maxAmount)), 0));

        return convertView;
    }
}
