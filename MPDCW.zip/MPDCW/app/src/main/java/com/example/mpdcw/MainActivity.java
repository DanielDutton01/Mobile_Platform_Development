package com.example.mpdcw;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Application;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.ViewAnimator;
import android.widget.ViewSwitcher;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;


public class MainActivity extends AppCompatActivity implements OnMapReadyCallback, View.OnClickListener {

    GoogleMap mMap;

    ListView infoList;

    TextView LocationView;
    TextView MagnitudeView;
    TextView LocText;
    TextView MagText;
    TextView DateText;
    TextView DepthText;
    TextView LatLonText;

    Button locationButton;
    Button returnButton, returnButton2, returnButton3;
    Button mapButton;
    Button buttonN, buttonS, buttonE, buttonW, buttonMag, buttonLD, buttonHD;

    ViewAnimator avw;

    Spinner fromSpin;
    Spinner toSpin;

    int fromPos=0;
    int toPos=50;

    ArrayList<String> location;
    ArrayList<String> mag;
    ArrayList<String> date;
    ArrayList<String> depth;
    ArrayList<String> lat;
    ArrayList<String> lon;

    ArrayList<Date> pickDate;
    ArrayList<Date> pickDate2;
    ArrayList<String> pickDateString;

    ArrayList<Date> dateSort;
    ArrayList<String> dateLoc;
    ArrayList<String> dateMag;
    ArrayList<String> dateDepth;
    ArrayList<String> datelat;
    ArrayList<String> datelon;

    ArrayList<Float> currentMag;

    ArrayList<HashMap<String,String>> arrayList;

    LatLng selectedItem;
    boolean placedMarkers = false;
    boolean specSort = false;
    boolean chosenValue = false;

    String[] from;
    int[] to;

    float maxMag = 0;
    float sDepth = 0;
    float mDepth = 0;
    float minLat=0;
    float maxLat=0;
    float minLon=0;
    float maxLon=0;

    int currentPos;
    int chosenMag, chosenN, chosenS, chosenE, chosenW, chosenMD, chosenLD;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        infoList = (ListView) findViewById(R.id.infoList);

        LocationView = (TextView) findViewById(R.id.LocationView);
        MagnitudeView = (TextView) findViewById(R.id.MagnitudeView);
        LocText = (TextView) findViewById(R.id.LocText);
        DateText = (TextView) findViewById(R.id.DateText);
        MagText = (TextView) findViewById(R.id.MagText);
        DepthText = (TextView) findViewById(R.id.DepthText);
        LatLonText = (TextView) findViewById(R.id.LatLonText);

        locationButton = (Button) findViewById(R.id.button3);
        returnButton = (Button) findViewById(R.id.returnButton);
        returnButton2 = (Button) findViewById(R.id.returnButton2);
        returnButton3 = (Button) findViewById(R.id.returnButton3);
        mapButton = (Button) findViewById(R.id.mapButton);

        avw = (ViewAnimator) findViewById(R.id.vwSwitch);

        fromSpin = (Spinner) findViewById(R.id.spinner1) ;
        toSpin = (Spinner) findViewById(R.id.spinner2);

        buttonN = (Button) findViewById(R.id.NorthButton);
        buttonS = (Button) findViewById(R.id.SouthButton);
        buttonE = (Button) findViewById(R.id.EastButton);
        buttonW = (Button) findViewById(R.id.WestButton);
        buttonMag = (Button) findViewById(R.id.HMButton);
        buttonHD = (Button) findViewById(R.id.HDButton);
        buttonLD = (Button) findViewById(R.id.SDButton);

        buttonN.setOnClickListener(this);
        buttonS.setOnClickListener(this);
        buttonE.setOnClickListener(this);
        buttonW.setOnClickListener(this);
        buttonMag.setOnClickListener(this);
        buttonHD.setOnClickListener(this);
        buttonLD.setOnClickListener(this);

        location = new ArrayList<String>();
        mag = new ArrayList<String>();
        date = new ArrayList<String>();
        depth = new ArrayList<String>();
        lat = new ArrayList<String>();
        lon = new ArrayList<String>();
        pickDate=new ArrayList<Date>();
        pickDate2=new ArrayList<Date>();
        pickDateString=new ArrayList<String>();
        dateSort = new ArrayList<Date>();
        dateLoc = new ArrayList<String>();
        dateMag= new ArrayList<String>();
        dateDepth = new ArrayList<String>();
        datelat = new ArrayList<String>();
        datelon = new ArrayList<String>();
        currentMag = new ArrayList<Float>();
        arrayList = new ArrayList<>();
        from = new String[]{"Location", "Magnitude"};
        to = new int[]{R.id.LocationView,R.id.MagnitudeView};

        for(int i = 0; i<51;i++)
        {
            Calendar cDate = Calendar.getInstance();;
            cDate.add(Calendar.DATE,-50+i);
            cDate.set(Calendar.HOUR_OF_DAY, 0);
            cDate.set(Calendar.MINUTE, 0);
            cDate.set(Calendar.SECOND, 0);
            Date date = new Date(cDate.getTimeInMillis());

            cDate.set(Calendar.HOUR_OF_DAY, 23);
            cDate.set(Calendar.MINUTE, 59);
            cDate.set(Calendar.SECOND, 59);
            Date date2 = new Date(cDate.getTimeInMillis());

            SimpleDateFormat format = new SimpleDateFormat("dd/MM/YYYY");
            String stringDate = format.format(date);
            pickDate.add(date);
            pickDate2.add(date2);
            pickDateString.add(stringDate);
        }

        dateChecker();

        infoList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                checkInfo(position);
            }
        });

        fromSpin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position>toPos)
                {
                    fromPos=toPos-1;
                }
                fromPos=position;
                dateChecker();
                Log.e("MyBTag", dateMag.toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        toSpin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position<fromPos)
                {
                    toPos=fromPos+1;
                }
                toPos=position;
                dateChecker();
                Log.e("MyBTag", dateMag.toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



        locationButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                avw.showNext();
                avw.showNext();
                avw.showNext();
            }
        });

        returnButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                avw.showPrevious();
            }
        });

        returnButton2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                avw.showPrevious();
                avw.showPrevious();
            }
        });

        returnButton3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                avw.showPrevious();
                avw.showPrevious();
                avw.showPrevious();
            }
        });

        mapButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                avw.showPrevious();
                moveMap(currentPos);
            }
        });

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        new BackgroundProcesses().execute();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        // Checks the orientation of the screen
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            Log.e("MyCTag", "AAA");
            //this is here for the demonstration of the screen as there seems to be a bug that won't allow proper screen rotation.
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE);
            Log.e("MyCTag", "ABA");
        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT){
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            Log.e("MyCTag", "BBB");
        }

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.NorthButton:
                FinalSort(0);
                avw.showPrevious();
                avw.showPrevious();
                avw.showPrevious();
                break;
            case R.id.SouthButton:
                FinalSort(1);
                avw.showPrevious();
                avw.showPrevious();
                avw.showPrevious();
                break;
            case R.id.EastButton:
                FinalSort(2);
                avw.showPrevious();
                avw.showPrevious();
                avw.showPrevious();
                break;
            case R.id.WestButton:
                FinalSort(3);
                avw.showPrevious();
                avw.showPrevious();
                avw.showPrevious();
                break;
            case R.id.HMButton:
                FinalSort(4);
                avw.showPrevious();
                avw.showPrevious();
                avw.showPrevious();
                break;
            case R.id.HDButton:
                FinalSort(5);
                avw.showPrevious();
                avw.showPrevious();
                avw.showPrevious();
                  break;
            case R.id.SDButton:
                FinalSort(6);
                avw.showPrevious();
                avw.showPrevious();
                avw.showPrevious();
                 break;
        }
    }

    public void checkInfo(int position)
    {
        Log.e("MyCTag", String.valueOf(currentPos));
        avw.showNext();
        avw.showNext();
        if(specSort==false){
            Log.e("MyBTag", "iAi");
            currentPos = position;
        }
        LocText.setText(dateLoc.get(currentPos));
        DateText.setText(dateSort.get(currentPos).toString());
        MagText.setText(dateMag.get(currentPos));
        DepthText.setText(dateDepth.get(currentPos));
        LatLonText.setText(datelat.get(currentPos) + ", " + datelon.get(currentPos));
    }

    public void moveMap(int position)
    {
        selectedItem = new LatLng(Float.parseFloat(datelat.get(position)),Float.parseFloat(datelon.get(position)));
        CameraUpdate loc = CameraUpdateFactory.newLatLngZoom(selectedItem, 10);
        mMap.animateCamera(loc);
    }

    public void dateChecker()
    {
        specSort=false;
        getAllSort();

        ArrayList<Date> tempDates = new ArrayList<Date>();
        ArrayList<Float> numMag = new ArrayList<Float>();

        currentMag = new ArrayList<Float>();

        dateSort = new ArrayList<Date>();
        dateLoc = new ArrayList<String>();
        dateMag= new ArrayList<String>();
        dateDepth = new ArrayList<String>();
        datelat = new ArrayList<String>();
        datelon = new ArrayList<String>();

        if(placedMarkers)
        {
            mMap.clear();
            placedMarkers=false;
            mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
            mMap.getUiSettings().setZoomControlsEnabled(true);
            mMap.getUiSettings().setZoomGesturesEnabled(true);
            mMap.getUiSettings().setCompassEnabled(true);
        }

        for(int i = 0; i<date.size(); i++)
        {
            SimpleDateFormat format = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss");
            String stringDate = date.get(i).toString();
            String newDepth = depth.get(i);

            try {
                Date dateString = format.parse(stringDate);
                tempDates.add(dateString);
                numMag.add(Float.parseFloat(mag.get(i)));
            } catch (ParseException e) {
                e.printStackTrace();
            }

            if(tempDates.get(i).after(pickDate.get(fromPos)))
            {
                if(tempDates.get(i).before(pickDate2.get(toPos)))
                {
                    dateSort.add(tempDates.get(i));
                    dateLoc.add(location.get(i));
                    dateMag.add(mag.get(i));
                    dateDepth.add(depth.get(i));
                    datelat.add(lat.get(i));
                    datelon.add(lon.get(i));

                    currentMag.add(numMag.get(i));
                }
            }
        }

        if(!placedMarkers)
        {
            for (int i = 0; i < dateLoc.size(); i++) {
                LatLng loc = new LatLng(Float.parseFloat(datelat.get(i)), Float.parseFloat(datelon.get(i)));
                MarkerOptions opt = new MarkerOptions().position(loc).title(dateLoc.get(i));
                if(currentMag.get(i) <= maxMag) {
                    opt.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED));
                }
                if(currentMag.get(i) < (maxMag/3*2)) {
                    opt.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE));
                }
                if(currentMag.get(i) < (maxMag/3)) {
                    opt.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN));
                }
                mMap.addMarker(opt);
            }
            placedMarkers=true;
        }

        getAllSort();

        infoList.setAdapter(null);
        ArrayList<MainListData> firstDisplayList = new ArrayList<>();
        //populates the list array
        for(int i = 0; i < dateSort.size(); i++)
        {
            MainListData info = new MainListData(dateLoc.get(i), dateMag.get(i), maxMag);
            firstDisplayList.add(info);
        }
        //creates the list adapter
        ColourAdapter cAdapter = new ColourAdapter(MainActivity.this, R.layout.info_list_view_items, firstDisplayList);
        infoList.setAdapter(cAdapter);
    }

    public void FinalSort(int sort)
    {
        chosenValue=true;
        dateChecker();

        ArrayList<Float> numMag = new ArrayList<Float>();
        ArrayList<Float> numDepth = new ArrayList<Float>();
        ArrayList<Float> numLat = new ArrayList<Float>();
        ArrayList<Float> numLon = new ArrayList<Float>();

        for(int i = 0; i<dateSort.size(); i++)
        {
            String stringDate = date.get(i).toString();
            String newDepth = dateDepth.get(i);

            numMag.add(Float.parseFloat(dateMag.get(i)));
            numDepth.add(Float.parseFloat(newDepth.replaceAll("\\D+","")));
            numLat.add(Float.parseFloat(datelat.get(i)));
            numLon.add(Float.parseFloat(datelon.get(i)));

                if (numMag.get(i) == maxMag) {
                    chosenMag = i;
                    Log.e("MyBTag", String.valueOf(chosenMag));
                }
                if (numDepth.get(i) == mDepth) {
                    chosenMD = i;
                    Log.e("MyBTag", String.valueOf(chosenMag));
                }
                if (numDepth.get(i) == sDepth) {
                    chosenLD = i;
                    Log.e("MyBTag", String.valueOf(chosenMag));
                }
                if (numLat.get(i) == minLat) {
                    chosenS = i;
                    Log.e("MyBTag", String.valueOf(chosenMag));
                }
                if (numLat.get(i) == maxLat) {
                    chosenN = i;
                    Log.e("MyBTag", String.valueOf(chosenMag));
                }
                if (numLon.get(i) == minLon) {
                    chosenE = i;
                    Log.e("MyBTag", String.valueOf(chosenMag));
                }
                if (numLon.get(i) == maxLon) {
                    chosenW = i;
                    Log.e("MyBTag", String.valueOf(chosenMag));
                }


        }

        Log.e("MyBTag", String.valueOf(maxMag));
//                    Log.e("MyBTag", String.valueOf(numMag.get(i)));
//                    Log.e("MyBTag", String.valueOf(chosenMag));
//                    Log.e("MyBTag", String.valueOf(i));
//                    Log.e("MyBTag", String.valueOf(date.size()));

        specSort=true;
        infoList.setAdapter(null);
        ArrayList<MainListData> firstDisplayList = new ArrayList<>();

        if(placedMarkers)
        {
            mMap.clear();
            placedMarkers=false;
            mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
            mMap.getUiSettings().setZoomControlsEnabled(true);
            mMap.getUiSettings().setZoomGesturesEnabled(true);
            mMap.getUiSettings().setCompassEnabled(true);
        }

        if(dateSort.size()>0) {
            if (sort == 0) {
                MainListData info = new MainListData(dateLoc.get(chosenN), dateMag.get(chosenN), maxMag);
                firstDisplayList.add(info);
                currentPos=chosenN;
            }
            if (sort == 1) {
                MainListData info = new MainListData(dateLoc.get(chosenS), dateMag.get(chosenS), maxMag);
                firstDisplayList.add(info);
                currentPos=chosenS;
            }
            if (sort == 2) {
                MainListData info = new MainListData(dateLoc.get(chosenE), dateMag.get(chosenE), maxMag);
                firstDisplayList.add(info);
                currentPos=chosenE;
            }
            if (sort == 3) {
                MainListData info = new MainListData(dateLoc.get(chosenW), dateMag.get(chosenW), maxMag);
                firstDisplayList.add(info);
                currentPos=chosenW;
            }
            if (sort == 4) {
                MainListData info = new MainListData(dateLoc.get(chosenMag), dateMag.get(chosenMag), maxMag);
                firstDisplayList.add(info);
                currentPos=chosenMag;
            }
            if (sort == 5) {
                MainListData info = new MainListData(dateLoc.get(chosenMD), dateMag.get(chosenMD), maxMag);
                firstDisplayList.add(info);
                currentPos=chosenMD;
            }
            if (sort == 6) {
                MainListData info = new MainListData(dateLoc.get(chosenLD), dateMag.get(chosenLD), maxMag);
                firstDisplayList.add(info);
                currentPos=chosenLD;
            }

            if(!placedMarkers)
            {
                LatLng loc = new LatLng(Float.parseFloat(datelat.get(currentPos)), Float.parseFloat(datelon.get(currentPos)));
                MarkerOptions opt = new MarkerOptions().position(loc).title(dateLoc.get(currentPos));
                opt.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED));

                mMap.addMarker(opt);
                placedMarkers=true;
            }
        }
        //creates the list adapter
        ColourAdapter cAdapter = new ColourAdapter(MainActivity.this, R.layout.info_list_view_items, firstDisplayList);
        infoList.setAdapter(cAdapter);
    }

    public void getAllSort()
    {
        ArrayList<Float> tempMag = new ArrayList<Float>();
        ArrayList<Float> tempD = new ArrayList<Float>();
        ArrayList<Float> tempLat = new ArrayList<Float>();
        ArrayList<Float> tempLon = new ArrayList<Float>();

        for (int i = 0; i<dateSort.size();i++)
        {
            float dm, dd, dl, dl2;
            String dStr = dateDepth.get(i);
            try {
                dm=Float.parseFloat(dateMag.get(i));
                tempMag.add(dm);

                dd=Float.parseFloat(dStr.replaceAll("\\D+",""));
                tempD.add(dd);

                dl=Float.parseFloat(datelat.get(i));
                tempLat.add(dl);

                dl2=Float.parseFloat(datelon.get(i));
                tempLon.add(dl2);
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }

        Collections.sort(tempMag);
        Collections.sort(tempD);
        Collections.sort(tempLat);
        Collections.sort(tempLon);

        if(dateSort.size()==0)
        {
            maxMag = 0;
            sDepth = 0;
            mDepth = 0;
            minLat = 0;
            maxLat = 0;
            minLon = 0;
            maxLon = 0;
        }
        if(dateSort.size()>0)
        {
            maxMag = tempMag.get(0);
            sDepth = tempD.get(0);
            mDepth = tempD.get(0);
            minLat = tempLat.get(0);
            maxLat = tempLat.get(0);
            minLon = tempLon.get(0);
            maxLon = tempLon.get(0);
        }
        if(dateSort.size()>1) {
            maxMag = tempMag.get(tempMag.size() - 1);
            sDepth = tempD.get(0);
            mDepth = tempD.get(tempD.size()-1);
            minLat = tempLat.get(0);
            maxLat = tempLat.get(tempLat.size()-1);
            minLon = tempLon.get(0);
            maxLon = tempLon.get(tempLon.size()-1);
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap)
    {
        mMap = googleMap;
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setZoomGesturesEnabled(true);
        mMap.getUiSettings().setCompassEnabled(true);
      //  LatLng defaultLL = new LatLng(55.86,-4.25);
       // mMap.moveCamera(CameraUpdateFactory.newLatLng(defaultLL));
    }

    public InputStream getIS(URL url)
    {
        try
        {
            return url.openConnection().getInputStream();
        }
        catch (IOException ae)
        {
            Log.e("MyTag", "ioexception in run");
            return null;
        }
    }

    public class BackgroundProcesses extends AsyncTask<Integer, Void, Exception>
    {
        ProgressDialog pDialog = new ProgressDialog(MainActivity.this);
        Exception ex = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog.setMessage("Loading...");
            pDialog.show();
        }

        @Override
        protected Exception doInBackground(Integer... params) {
            try
            {
                URL urlSource = new URL("https://quakes.bgs.ac.uk/feeds/MhSeismology.xml");

                XmlPullParserFactory pullParserFactory = XmlPullParserFactory.newInstance();
                pullParserFactory.setNamespaceAware(false);

                XmlPullParser pullParser = pullParserFactory.newPullParser();
                pullParser.setInput(getIS(urlSource), "UTF-8");

                boolean itemData = false;
                int eventType = pullParser.getEventType();

                while(eventType != XmlPullParser.END_DOCUMENT) {
                    if (eventType == XmlPullParser.START_TAG) {
                        if (pullParser.getName().equalsIgnoreCase("item")) {
                            itemData = true;
                        } else if (pullParser.getName().equalsIgnoreCase("description")) {
                            if (itemData) {
                                String cString = pullParser.nextText();
                                String[] sepString;
                                String[] sepString2;
                                HashMap<String, String> hashMap = new HashMap<>();

                                //split the description
                                sepString = null;
                                sepString = cString.split(";");

                                //split the words from the information
                                sepString2 = null;
                                sepString2 = sepString[1].split(":");
                                sepString2[1].trim();
                                Log.e("MyTag", sepString2[1]);
                                //add to the location array
                                location.add(sepString2[1]);
                                hashMap.put("Location", sepString2[1]);

                                //redo the splitting for the depth
                                sepString2 = null;
                                sepString2 = sepString[3].split(":");
                                sepString2[1].trim();
                               // Log.e("MyTag", sepString2[1]);
                                depth.add(sepString2[1]);
                                hashMap.put("Magnitude", sepString2[1]);

                                Log.e("MyTag", cString);


                                //redo the splitting for the magnitude
                                sepString2 = null;
                                sepString2 = sepString[4].split(":");
                                sepString2[1].trim();
                              //  Log.e("MyTag", sepString2[1]);
                                mag.add(sepString2[1]);
                                hashMap.put("Magnitude", sepString2[1]);

                               // Log.e("MyTag", cString);

                                float newMag = Float.parseFloat(sepString2[1]);


                                if(newMag > maxMag)
                                {
                                    Log.e("MyTagA", Float.toString(maxMag));
                                    Log.e("MyTagA", Float.toString(newMag));
                                    maxMag = newMag;
                                }

                                arrayList.add((hashMap));
                            }
                        } else if (pullParser.getName().equalsIgnoreCase("pubDate")) {
                            if (itemData) {
                                String cString = pullParser.nextText();
                                Log.e("MyTag", cString);
                                date.add(cString);
                            }
                        } else if(pullParser.getName().equalsIgnoreCase("geo:lat"))
                        {
                            if (itemData) {
                                String cString = pullParser.nextText();
                                Log.e("MyTag", cString);
                                lat.add(cString);

                            }
                        } else if(pullParser.getName().equalsIgnoreCase("geo:long"))
                        {
                            if (itemData) {
                                String cString = pullParser.nextText();
                                Log.e("MyTag", cString);
                                lon.add(cString);
                            }
                        }
                    } else if (eventType == XmlPullParser.END_TAG && pullParser.getName().equalsIgnoreCase("item")) {
                        itemData = false;
                    }
                    eventType = pullParser.next();
                }
            }
            catch (MalformedURLException ae)
            {
                ex = ae;
            }
            catch (XmlPullParserException ae)
            {
                ex = ae;
            }
            catch (IOException ae)
            {
                ex = ae;
            }
            catch(NumberFormatException ae) {
                ex = ae;
            }
            return ex;
        }

        @Override
        protected void onPostExecute(Exception s) {
            super.onPostExecute(s);
            // ArrayAdapter<String> aAdapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, location);
            // SimpleAdapter sAdapter = new SimpleAdapter(MainActivity.this, arrayList, R.layout.info_list_view_items, from, to);

            //this, android.R.layout.simple_spinner_dropdown_item, pickDate
            //creates array adapter for dropdowns
            ArrayAdapter<String> calAd = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_spinner_dropdown_item, pickDateString);

            fromSpin.setAdapter(calAd);
            toSpin.setAdapter(calAd);
            fromSpin.setSelection(fromPos);
            toSpin.setSelection(toPos);

            //creates appropriate array for the MainListData
            ArrayList<MainListData> firstDisplayList = new ArrayList<>();
            //populates the list array
            for(int i = 0; i < dateSort.size(); i++)
            {
                MainListData info = new MainListData(dateLoc.get(i), dateMag.get(i), maxMag);
                firstDisplayList.add(info);
            }
            //creates the list adapter
            ColourAdapter cAdapter = new ColourAdapter(MainActivity.this, R.layout.info_list_view_items, firstDisplayList);

            //applies adapter
            infoList.setAdapter(cAdapter);
            pDialog.dismiss();
        }
    }


}